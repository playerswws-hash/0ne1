#import <UIKit/UIKit.h>
#import <ImageIO/ImageIO.h>
#import <objc/runtime.h>

// Папка с GIF: 0.gif ... 9.gif, colon.gif (необязательно)
#define ANI_DIR @"/var/jb/Library/AniTime"
// Минимальный размер шрифта, чтобы считать UILabel часами экрана блокировки
#define CLOCK_MIN_FONT 60.0
// Высота цифры относительно высоты метки
#define DIGIT_SCALE 0.85
// Расстояние между цифрами (pt, может быть отрицательным)
#define DIGIT_GAP -4.0

static NSMutableDictionary<NSString *, UIImage *> *gCache;
static const void *kOverlayKey = &kOverlayKey;

static UIImage *ATImage(NSString *name) {
    if (!gCache) gCache = [NSMutableDictionary new];
    UIImage *cached = gCache[name];
    if (cached) return cached;

    NSData *data = [NSData dataWithContentsOfFile:[NSString stringWithFormat:@"%@/%@.gif", ANI_DIR, name]];
    if (!data) return nil;
    CGImageSourceRef src = CGImageSourceCreateWithData((__bridge CFDataRef)data, NULL);
    if (!src) return nil;

    size_t count = CGImageSourceGetCount(src);
    NSMutableArray<UIImage *> *frames = [NSMutableArray new];
    NSTimeInterval total = 0;
    for (size_t i = 0; i < count; i++) {
        CGImageRef cg = CGImageSourceCreateImageAtIndex(src, i, NULL);
        if (!cg) continue;
        [frames addObject:[UIImage imageWithCGImage:cg]];
        CGImageRelease(cg);

        NSDictionary *props = (__bridge_transfer NSDictionary *)CGImageSourceCopyPropertiesAtIndex(src, i, NULL);
        NSDictionary *gif = props[(__bridge NSString *)kCGImagePropertyGIFDictionary];
        NSNumber *delay = gif[(__bridge NSString *)kCGImagePropertyGIFUnclampedDelayTime];
        if (delay.doubleValue <= 0) delay = gif[(__bridge NSString *)kCGImagePropertyGIFDelayTime];
        total += (delay.doubleValue > 0.01) ? delay.doubleValue : 0.1;
    }
    CFRelease(src);
    if (frames.count == 0) return nil;

    UIImage *img = (frames.count == 1) ? frames[0]
                                       : [UIImage animatedImageWithImages:frames duration:total];
    gCache[name] = img;
    return img;
}

static NSString *ATName(unichar c) {
    if (c >= '0' && c <= '9') return [NSString stringWithFormat:@"%C", c];
    if (c == ':' || c == 0x2236) return @"colon";
    return nil;
}

static BOOL ATLooksLikeClock(NSString *s) {
    if (s.length < 4 || s.length > 5) return NO;
    static NSRegularExpression *re;
    static dispatch_once_t once;
    dispatch_once(&once, ^{
        re = [NSRegularExpression regularExpressionWithPattern:@"^[0-9]{1,2}[:\u2236][0-9]{2}$"
                                                       options:0 error:nil];
    });
    return [re numberOfMatchesInString:s options:0 range:NSMakeRange(0, s.length)] > 0;
}

static void ATRemoveOverlay(UILabel *label) {
    UIView *ov = objc_getAssociatedObject(label, kOverlayKey);
    if (ov) {
        [ov removeFromSuperview];
        objc_setAssociatedObject(label, kOverlayKey, nil, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
        label.alpha = 1.0;
    }
}

static void ATUpdate(UILabel *label) {
    if (label.font.pointSize < CLOCK_MIN_FONT) return;

    NSString *text = label.text ?: label.attributedText.string;
    if (!ATLooksLikeClock(text)) { ATRemoveOverlay(label); return; }

    UIView *host = label.superview;
    CGFloat labelH = label.bounds.size.height;
    if (!host || labelH <= 0) return;

    UIView *ov = objc_getAssociatedObject(label, kOverlayKey);
    BOOL needsBuild = !ov || ![ov.accessibilityIdentifier isEqualToString:text]
                      || ov.tag != (NSInteger)labelH;

    if (needsBuild) {
        // Собираем картинки; если цифры не найдены, оставляем оригинал
        NSMutableArray<UIImage *> *imgs = [NSMutableArray new];
        for (NSUInteger i = 0; i < text.length; i++) {
            NSString *n = ATName([text characterAtIndex:i]);
            UIImage *im = n ? ATImage(n) : nil;
            if (!im && ![n isEqualToString:@"colon"]) return;
            [imgs addObject:im ?: (UIImage *)[NSNull null]];
        }

        [ov removeFromSuperview];
        ov = [[UIView alloc] initWithFrame:label.frame];
        ov.userInteractionEnabled = NO;
        ov.accessibilityIdentifier = text;
        ov.tag = (NSInteger)labelH;

        CGFloat h = labelH * DIGIT_SCALE;
        CGFloat y = (labelH - h) / 2.0;
        CGFloat x = 0;
        for (id obj in imgs) {
            if (obj == (id)[NSNull null]) { x += h * 0.25 + DIGIT_GAP; continue; }
            UIImage *im = obj;
            CGFloat w = (im.size.height > 0) ? h * im.size.width / im.size.height : h * 0.6;
            UIImageView *iv = [[UIImageView alloc] initWithFrame:CGRectMake(x, y, w, h)];
            iv.image = im;
            iv.contentMode = UIViewContentModeScaleAspectFit;
            [ov addSubview:iv];
            x += w + DIGIT_GAP;
        }
        // Центрируем ряд внутри метки
        CGFloat rowW = x - DIGIT_GAP;
        CGFloat shift = (label.bounds.size.width - rowW) / 2.0;
        for (UIView *v in ov.subviews) {
            CGRect f = v.frame; f.origin.x += shift; v.frame = f;
        }

        [host insertSubview:ov aboveSubview:label];
        objc_setAssociatedObject(label, kOverlayKey, ov, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    }

    ov.frame = label.frame;
    label.alpha = 0.0;
}

%hook UILabel
- (void)setText:(NSString *)text {
    %orig;
    ATUpdate(self);
}
- (void)setAttributedText:(NSAttributedString *)text {
    %orig;
    ATUpdate(self);
}
- (void)layoutSubviews {
    %orig;
    ATUpdate(self);
}
%end
