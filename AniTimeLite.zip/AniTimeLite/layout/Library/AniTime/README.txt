Положи сюда GIF-файлы: 0.gif 1.gif ... 9.gif и (по желанию) colon.gif
Путь на телефоне: /var/jb/Library/AniTime/
